.com|whois.crsnic.net|No match for
.net|whois.crsnic.net|No match for
.org|whois.publicinterestregistry.net|NOT FOUND
.uk|whois.nic.uk|No match
.co.uk|whois.nic.uk|No match
.net.uk|whois.nic.uk|No match
.org.uk|whois.nic.uk|No match
.ltd.uk|whois.nic.uk|No match
.plc.uk|whois.nic.uk|No match
.me.uk|whois.nic.uk|No match
.edu|whois.internic.net|No match for
.mil|whois.internic.net|No match for
.br.com|whois.centralnic.com|DOMAIN NOT FOUND
.cn.com|whois.centralnic.com|DOMAIN NOT FOUND
.eu.com|whois.centralnic.com|DOMAIN NOT FOUND
.hu.com|whois.centralnic.com|DOMAIN NOT FOUND
.no.com|whois.centralnic.com|DOMAIN NOT FOUND
.qc.com|whois.centralnic.com|DOMAIN NOT FOUND
.sa.com|whois.centralnic.com|DOMAIN NOT FOUND
.se.com|whois.centralnic.com|DOMAIN NOT FOUND
.se.net|whois.centralnic.com|DOMAIN NOT FOUND
.us.com|whois.centralnic.com|DOMAIN NOT FOUND
.uy.com|whois.centralnic.com|DOMAIN NOT FOUND
.za.com|whois.centralnic.com|DOMAIN NOT FOUND
.ac|whois.nic.ac|is available for purchase
.co.ac|whois.nic.ac|is not registered
.gv.ac|whois.nic.ac|is not registered
.or.ac|whois.nic.ac|is not registered
.ac.ac|whois.nic.ac|is not registered
.af|whois.nic.af|No Object Found
.am|whois.amnic.net|No match
.as|whois.nic.as|Available
.at|whois.nic.at|nothing found
.ac.at|whois.nic.at|nothing found
.co.at|whois.nic.at|nothing found
.gv.at|whois.nic.at|nothing found
.or.at|whois.nic.at|nothing found
.asn.au|whois.audns.net.au|No Data Found
.com.au|whois.audns.net.au|No Data Found
.edu.au|whois.audns.net.au|No Data Found
.org.au|whois.audns.net.au|No Data Found
.net.au|whois.audns.net.au|No Data Found
.id.au|whois.audns.net.au|No Data Found
.be|whois.dns.be|Status:	AVAILABLE
.ac.be|whois.dns.be|No such domain
.br|whois.nic.br|No match for
.adm.br|whois.nic.br|No match for
.adv.br|whois.nic.br|No match for
.am.br|whois.nic.br|No match for
.arq.br|whois.nic.br|No match for
.art.br|whois.nic.br|No match for
.bio.br|whois.nic.br|No match for
.cng.br|whois.nic.br|No match for
.cnt.br|whois.nic.br|No match for
.com.br|whois.nic.br|No match for
.ecn.br|whois.nic.br|No match for
.eng.br|whois.nic.br|No match for
.esp.br|whois.nic.br|No match for
.etc.br|whois.nic.br|No match for
.eti.br|whois.nic.br|No match for
.fm.br|whois.nic.br|No match for
.fot.br|whois.nic.br|No match for
.fst.br|whois.nic.br|No match for
.g12.br|whois.nic.br|No match for
.gov.br|whois.nic.br|No match for
.ind.br|whois.nic.br|No match for
.inf.br|whois.nic.br|No match for
.jor.br|whois.nic.br|No match for
.lel.br|whois.nic.br|No match for
.med.br|whois.nic.br|No match for
.mil.br|whois.nic.br|No match for
.net.br|whois.nic.br|No match for
.nom.br|whois.nic.br|No match for
.ntr.br|whois.nic.br|No match for
.odo.br|whois.nic.br|No match for
.org.br|whois.nic.br|No match for
.ppg.br|whois.nic.br|No match for
.pro.br|whois.nic.br|No match for
.psc.br|whois.nic.br|No match for
.psi.br|whois.nic.br|No match for
.rec.br|whois.nic.br|No match for
.slg.br|whois.nic.br|No match for
.tmp.br|whois.nic.br|No match for
.tur.br|whois.nic.br|No match for
.tv.br|whois.nic.br|No match for
.vet.br|whois.nic.br|No match for
.zlg.br|whois.nic.br|No match for
.ca|whois.cira.ca|Domain status:         available
.cc|whois.nic.cc|No match
.cn|whois.cnnic.net.cn|No matching record
.ac.cn|whois.cnnic.net.cn|No matching record
.com.cn|whois.cnnic.net.cn|No matching record
.edu.cn|whois.cnnic.net.cn|No matching record
.gov.cn|whois.cnnic.net.cn|No matching record
.net.cn|whois.cnnic.net.cn|No matching record
.org.cn|whois.cnnic.net.cn|No matching record
.bj.cn|whois.cnnic.net.cn|No matching record
.sh.cn|whois.cnnic.net.cn|No matching record
.tj.cn|whois.cnnic.net.cn|No matching record
.cq.cn|whois.cnnic.net.cn|No matching record
.he.cn|whois.cnnic.net.cn|No matching record
.nm.cn|whois.cnnic.net.cn|No matching record
.ln.cn|whois.cnnic.net.cn|No matching record
.jl.cn|whois.cnnic.net.cn|No matching record
.hl.cn|whois.cnnic.net.cn|No matching record
.js.cn|whois.cnnic.net.cn|No matching record
.zj.cn|whois.cnnic.net.cn|No matching record
.ah.cn|whois.cnnic.net.cn|No matching record
.hb.cn|whois.cnnic.net.cn|No matching record
.hn.cn|whois.cnnic.net.cn|No matching record
.gd.cn|whois.cnnic.net.cn|No matching record
.gx.cn|whois.cnnic.net.cn|No matching record
.hi.cn|whois.cnnic.net.cn|No matching record
.sc.cn|whois.cnnic.net.cn|No matching record
.scot|whois.scot.coreregistry.net|no matching objects found
.gz.cn|whois.cnnic.net.cn|No matching record
.yn.cn|whois.cnnic.net.cn|No matching record
.xz.cn|whois.cnnic.net.cn|No matching record
.sn.cn|whois.cnnic.net.cn|No matching record
.gs.cn|whois.cnnic.net.cn|No matching record
.qh.cn|whois.cnnic.net.cn|No matching record
.nx.cn|whois.cnnic.net.cn|No matching record
.xj.cn|whois.cnnic.net.cn|No matching record
.tw.cn|whois.cnnic.net.cn|No matching record
.hk.cn|whois.cnnic.net.cn|No matching record
.mo.cn|whois.cnnic.net.cn|No matching record
.cx|whois.nic.cx|No match for
.cz|whois.nic.cz|No entries found
.de|whois.denic.de|Status: free
.com.de|whois.centralnic.com|Status: free
.dk|whois.dk-hostmaster.dk|No entries found
.fo|whois.nic.fo|no entries found
.com.ec|whois.lac.net|No match found
.org.ec|whois.lac.net|No match found
.net.ec|whois.lac.net|No match found
.mil.ec|whois.lac.net|No match found
.fin.ec|whois.lac.net|No match found
.med.ec|whois.lac.net|No match found
.gov.ec|whois.lac.net|No match found
.fr|whois.nic.fr|No entries found
.tm.fr|whois.nic.fr|No entries found
.com.fr|whois.nic.fr|No entries found
.asso.fr|whois.nic.fr|No entries found
.presse.fr|whois.nic.fr|No entries found
.gf|whois.nplus.gf|not found in our database
.co.il|whois.isoc.org.il|No data was found
.org.il|whois.isoc.org.il|No data was found
.net.il|whois.isoc.org.il|No data was found
.ac.il|whois.isoc.org.il|No data was found
.k12.il|whois.isoc.org.il|No data was found
.gov.il|whois.isoc.org.il|No data was found
.muni.il|whois.isoc.org.il|No data was found
.ac.in|whois.inregistry.in|NOT FOUND
.co.in|whois.inregistry.in|NOT FOUND
.org.in|whois.inregistry.in|NOT FOUND
.ernet.in|whois.inregistry.in|NOT FOUND
.gov.in|whois.inregistry.in|NOT FOUND
.net.in|whois.inregistry.in|NOT FOUND
.res.in|whois.inregistry.in|NOT FOUND
.is|whois.isnic.is|No entries found
.it|whois.nic.it|AVAILABLE
.ac.jp|whois.nic.ad.jp|No match!!
.co.jp|whois.nic.ad.jp|No match!!
.go.jp|whois.nic.ad.jp|No match!!
.or.jp|whois.nic.ad.jp|No match!!
.ne.jp|whois.nic.ad.jp|No match!!
.ac.kr|whois.nic.or.kr|domain was not found
.co.kr|whois.nic.or.kr|domain was not found
.go.kr|whois.nic.or.kr|domain was not found
.ne.kr|whois.nic.or.kr|domain was not found
.nm.kr|whois.nic.or.kr|domain was not found
.or.kr|whois.nic.or.kr|domain was not found
.re.kr|whois.nic.or.kr|domain was not found
.li|whois.nic.li|We do not have an entry in our database matching your query
.lt|das.domreg.lt|Status:			available
.lu|whois.dns.lu|No such domain
.asso.mc|whois.ripe.net|no entries found
.tm.mc|whois.ripe.net|no entries found
.com.mm|whois.nic.mm|No domains matched
.org.mm|whois.nic.mm|No domains matched
.net.mm|whois.nic.mm|No domains matched
.edu.mm|whois.nic.mm|No domains matched
.gov.mm|whois.nic.mm|No domains matched
.mx|whois.nic.mx|No_Se_Encontro_El_Objeto/Object_Not_Found
.com.mx|whois.nic.mx|Object_Not_Found
.org.mx|whois.nic.mx|Object_Not_Found
.net.mx|whois.nic.mx|Object_Not_Found
.edu.mx|whois.nic.mx|Object_Not_Found
.gov.mx|whois.nic.mx|Object_Not_Found
.gob.mx|whois.nic.mx|Object_Not_Found
.nl|whois.domain-registry.nl|is free
.no|whois.norid.no|No match
.nu|whois.nic.nu|not found
.pl|whois.dns.pl|No information available
.com.pl|whois.dns.pl|No information available
.net.pl|whois.dns.pl|No information available
.org.pl|whois.dns.pl|No information available
.aid.pl|whois.dns.pl|No information available
.agro.pl|whois.dns.pl|No information available
.atm.pl|whois.dns.pl|No information available
.auto.pl|whois.dns.pl|No information available
.biz.pl|whois.dns.pl|No information available
.edu.pl|whois.dns.pl|No information available
.gmina.pl|whois.dns.pl|No information available
.gsm.pl|whois.dns.pl|No information available
.info.pl|whois.dns.pl|No information available
.mail.pl|whois.dns.pl|No information available
.miasta.pl|whois.dns.pl|No information available
.media.pl|whois.dns.pl|No information available
.mil.pl|whois.dns.pl|No information available
.nom.pl|whois.dns.pl|No information available
.pc.pl|whois.dns.pl|No information available
.priv.pl|whois.dns.pl|No information available
.realestate.pl|whois.dns.pl|No information available
.rel.pl|whois.dns.pl|No information available
.shop.pl|whois.dns.pl|No information available
.sklep.pl|whois.dns.pl|No information available
.sos.pl|whois.dns.pl|No information available
.targi.pl|whois.dns.pl|No information available
.tm.pl|whois.dns.pl|No information available
.tourism.pl|whois.dns.pl|No information available
.travel.pl|whois.dns.pl|No information available
.turystyka.pl|whois.dns.pl|No information available
.ro|whois.rotld.ro|No entries found
.com.ro|whois.rotld.ro|No entries found
.org.ro|whois.rotld.ro|No entries found
.store.ro|whois.rotld.ro|No entries found
.tm.ro|whois.rotld.ro|No entries found
.firm.ro|whois.rotld.ro|No entries found
.www.ro|whois.rotld.ro|No entries found
.arts.ro|whois.rotld.ro|No entries found
.rec.ro|whois.rotld.ro|No entries found
.info.ro|whois.rotld.ro|No entries found
.nom.ro|whois.rotld.ro|No entries found
.nt.ro|whois.rotld.ro|No entries found
.se|whois.iis.se|not found
.si|whois.arnes.si|No entries found
.com.sg|whois.nic.net.sg|Domain Not Found
.org.sg|whois.nic.net.sg|Domain Not Found
.net.sg|whois.nic.net.sg|Domain Not Found
.gov.sg|whois.nic.net.sg|Domain Not Found
.sk|whois.sk-nic.sk|Not found
.st|whois.nic.st|No entries found
.tf|whois.nic.tf|No entries found
.ac.th|whois.thnic.net|No match for
.co.th|whois.thnic.net|No match for
.go.th|whois.thnic.net|No match for
.mi.th|whois.thnic.net|No match for
.net.th|whois.thnic.net|No match for
.or.th|whois.thnic.net|No match for
.in.th|whois.thnic.net|No match for
.tj|whois.nic.tj|No match
.to|monarch.tonic.to|No match for
.bbs.tr|whois.metu.edu.tr|No match found
.com.tr|whois.metu.edu.tr|No match found
.edu.tr|whois.metu.edu.tr|No match found
.gov.tr|whois.metu.edu.tr|No match found
.k12.tr|whois.metu.edu.tr|No match found
.mil.tr|whois.metu.edu.tr|No match found
.net.tr|whois.metu.edu.tr|No match found
.org.tr|whois.metu.edu.tr|No match found
.com.tw|whois.twnic.net|No Found
.org.tw|whois.twnic.net|No Found
.net.tw|whois.twnic.net|No Found
.ac.uk|whois.ja.net|Sorry - no
.uk.co|whois.uk.co|NO MATCH
.uk.com|whois.centralnic.com|DOMAIN NOT FOUND
.uk.net|whois.centralnic.com|DOMAIN NOT FOUND
.gb.com|whois.centralnic.com|DOMAIN NOT FOUND
.gb.net|whois.centralnic.com|DOMAIN NOT FOUND
.ac.za|whois.co.za|No information available
.alt.za|whois.co.za|No information available
.co.za|whois.registry.net.za|Available
.edu.za|whois.co.za|No information available
.gov.za|whois.co.za|No information available
.mil.za|whois.co.za|No information available
.net.za|net-whois.registry.net.za|Available
.ngo.za|whois.co.za|No information available
.nom.za|whois.co.za|No information available
.org.za|org-whois.registry.net.za|Available
.school.za|whois.co.za|No information available
.tm.za|whois.co.za|No information available
.web.za|web-whois.registry.net.za|Available
.kz|whois.domain.kz|No entries found
.ch|whois.nic.ch|We do not have an entry in our database matching your query
.info|whois.afilias.net|NOT FOUND
.ua|whois.ua|No entries found
.biz|whois.nic.biz|Not found
.ws|whois.website.ws|No match for
.gov|whois.nic.gov|No match for
.name|whois.nic.name|No match
.ie|whois.domainregistry.ie|% Not Registered
.hk|whois.hkirc.hk|The domain has not been registered
.com.hk|whois.hkdnr.net.hk|The domain has not been registered
.org.hk|whois.hkdnr.net.hk|The domain has not been registered
.net.hk|whois.hkdnr.net.hk|The domain has not been registered
.edu.hk|whois.hkdnr.net.hk|The domain has not been registered
.us|whois.nic.us|Not found
.tk|https://partners.nic.tk/cgi-bin/whmcs-whois.taloha?d=|HTTPREQUEST-has no matches
.cd|whois.cd|No match
.aero|whois.aero|NOT FOUND
.by|whois.cctld.by|Object does not exist
.ad|whois.ripe.net|no entries found
.lv|whois.nic.lv|Status: free
.eu.lv|whois.biz|Not found
.bz|whois.afilias-grs.info.|NOT FOUND
.es|whois.crsnic.net|No match for
.com.es|whois.crsnic.net|No match for
.nom.es|whois.crsnic.net|No match for
.gob.es|whois.crsnic.net|No match for
.edu.es|whois.crsnic.net|No match for
.jp|whois.jprs.jp|No match!!
.cl|whois.nic.cl|no existe
.ag|whois.nic.ag|NOT FOUND
.mobi|whois.dotmobiregistry.net|NOT FOUND
.eu|whois.eu|Status: AVAILABLE
.co.nz|whois.srs.net.nz|220 Available
.org.nz|whois.srs.net.nz|220 Available
.net.nz|whois.srs.net.nz|220 Available
.maori.nz|whois.srs.net.nz|220 Available
.iwi.nz|whois.srs.net.nz|220 Available
.ac.nz|whois.srs.net.nz|220 Available
.kiwi.nz|whois.srs.net.nz|220 Available
.geek.nz|whois.srs.net.nz|220 Available
.gen.nz|whois.srs.net.nz|220 Available
.school.nz|whois.srs.net.nz|220 Available
.nz|whois.srs.net.nz|220 Available
.io|whois.nic.io|is available
.la|whois.nic.la|NOT FOUND
.md|whois.nic.md|No match for
.sc|wawa.eahd.or.ug|No entries found
.sg|whois.nic.net.sg|Domain Not Found
.vc|whois.adamsnames.tc|Available
.tw|whois.twnic.net.tw|No Found
.travel|whois.nic.travel|Not found
.my|whois.mynic.my|does not exist in database
.com.my|whois.mynic.my|does not exist in database
.net.my|whois.mynic.my|does not exist in database
.org.my|whois.mynic.my|does not exist in database
.edu.my|whois.mynic.my|does not exist in database
.gov.my|whois.mynic.my|does not exist in database
.com.ph|http://www2.dot.ph/WhoIs.asp?Domain=|HTTPREQUEST-is still available
.net.ph|http://www2.dot.ph/WhoIs.asp?Domain=|HTTPREQUEST-is still available
.org.ph|https://whois.dot.ph/?search=|HTTPREQUEST-Domain is available
.ph|http://www2.dot.ph/WhoIs.asp?Domain=|HTTPREQUEST-is still available
.ngo.ph|http://www2.dot.ph/WhoIs.asp?Domain=|HTTPREQUEST-is still available
.tv|whois.nic.tv|No match for
.pt|whois.dns.pt|no match
.com.pt|whois.dns.pt|no match
.edu.pt|whois.dns.pt|no match
.in|whois.inregistry.in|NOT FOUND
.me|whois.meregistry.net|NOT FOUND
.asia|whois.nic.asia|NOT FOUND
.fi|whois.ficora.fi|Domain not found
.za.net|http://www.za.net/cgi-bin/whois.cgi?domain=|HTTPREQUEST-No such domain
.za.org|http://www.za.net/cgi-bin/whois.cgi?domain=|HTTPREQUEST-No such domain
.com.ve|whois.nic.ve|No match for
.net.ve|whois.nic.ve|No match for
.org.ve|whois.nic.ve|No match for
.web.ve|whois.nic.ve|No match for
.info.ve|whois.nic.ve|No match for
.co.ve|whois.nic.ve|No match for
.tel|whois.nic.tel|Not found
.im|whois.nic.im|was not found
.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.com.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.net.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.org.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.edu.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.gov.gr|http://grwhois.ics.forth.gr:800/plainwhois/plainWhois?domainName=|HTTPREQUEST-not exist
.ir|whois.nic.ir|no entries found
.ru|whois.ripn.net|No entries found
.pp.ru|whois.ripn.net|No entries found
.net.ru|whois.ripn.net|No entries found
.org.ru|whois.ripn.net|No entries found
.spb.ru|whois.relcom.ru|No entries found
.msk.ru|whois.relcom.ru|No entries found
.su|whois.ripn.net|No entries found
.com.ru|whois.ripn.net|No entries found
.com.ua|whois.net.ua|No entries found
.lviv.ua|whois.net.ua|No entries found
.dn.ua|whois.net.ua|No entries found
.kh.ua|whois.net.ua|No entries found
.lg.ua|whois.net.ua|No entries found
.net.ua|whois.net.ua|No entries found
.org.ua|whois.net.ua|No entries found
.kiev.ua|whois.net.ua|No entries found
.co|whois.nic.co|Not found
.net.co|whois.nic.co|Not found
.com.co|whois.nic.co|Not found
.nom.co|whois.nic.co|Not found
.edu.sg|whois.nic.net.sg|Domain Not Found
.com.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.net.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.org.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.ind.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.edu.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.gob.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.mil.gt|http://www.gt/cgi-bin/whois.cgi?domain=|HTTPREQUEST-DOMINIO NO REGISTRADO
.pro|whois.registrypro.pro|NOT FOUND
.re|whois.nic.re|No entries found
.pm|whois.nic.pm|No entries found
.wf|whois.nic.wf|No entries found
.yt|whois.nic.yt|No entries found
.xxx|whois.nic.xxx|NOT FOUND
.hu|whois.nic.hu|No match
.ac.ke|whois.kenic.or.ke|No Object Found
.co.ke|whois.kenic.or.ke|No Object Found
.or.ke|whois.kenic.or.ke|No Object Found
.ne.ke|whois.kenic.or.ke|No Object Found
.mobi.ke|whois.kenic.or.ke|No Object Found
.info.ke|whois.kenic.or.ke|No Object Found
.go.ke|whois.kenic.or.ke|No Object Found
.me.ke|whois.kenic.or.ke|No Object Found
.sc.ke|whois.kenic.or.ke|No Object Found
.gd|whois.nic.gd|not found...
.rs|whois.rnids.rs|%ERROR:103
.co.rs|whois.rnids.rs|%ERROR:103
.org.rs|whois.rnids.rs|%ERROR:103
.edu.rs|whois.rnids.rs|%ERROR:103
.in.rs|whois.rnids.rs|%ERROR:103
.ae|whois.aeda.net.ae|No Data Found
.pw|whois.nic.pw|DOMAIN NOT FOUND
.cat|whois.cat|no matching objects found
.mil.id|whois.idnic.net.id|Not found
.go.id|whois.idnic.net.id|Not found
.fm|whois.nic.fm|Not Registered
.mn|whois.afilias-grs.info|NOT FOUND
.sx|whois.sx|Status: AVAILABLE
.pa|http://www.nic.pa/whois.php?nombre_d=|HTTPREQUEST-esta disponible para ser Registrado
.com.pa|http://www.nic.pa/whois.php?nombre_d=|HTTPREQUEST-esta disponible para ser Registrado
.net.pa|http://www.nic.pa/whois.php?nombre_d=|HTTPREQUEST-esta disponible para ser Registrado
.org.pa|http://www.nic.pa/whois.php?nombre_d=|HTTPREQUEST-esta disponible para ser Registrado
.equipment|whois.donuts.co|Domain not found
.gallery|whois.donuts.co|Domain not found
.graphics|whois.donuts.co|Domain not found
.lighting|whois.donuts.co|Domain not found
.photography|whois.donuts.co|Domain not found
.directory|whois.donuts.co|Domain not found
.technology|whois.donuts.co|Domain not found
.today|whois.donuts.co|Domain not found
.bike|whois.donuts.co|Domain not found
.clothing|whois.donuts.co|Domain not found
.guru|whois.donuts.co|Domain not found
.plumbing |whois.donuts.co|Domain not found
.singles|whois.donuts.co|Domain not found
.camera|whois.donuts.co|Domain not found
.estate|whois.donuts.co|Domain not found
.construction|whois.donuts.co|Domain not found
.contractors|whois.donuts.co|Domain not found
.kitchen|whois.donuts.co|Domain not found
.land|whois.donuts.co|Domain not found
.enterprises|whois.donuts.co|Domain not found
.holdings|whois.donuts.co|Domain not found
.ventures|whois.donuts.co|Domain not found
.diamonds|whois.donuts.co|Domain not found
.voyage|whois.donuts.co|Domain not found
.photos|whois.donuts.co|Domain not found
.shoes|whois.donuts.co|Domain not found
.careers|whois.donuts.co|Domain not found
.recipes|whois.donuts.co|Domain not found
.cm|whois.netcom.cm|Not Registered
.gs|whois.nic.gs|No Object Found
.ms|whois.nic.ms|No Object Found
.sh|whois.nic.sh|is available for purchase
.tm|whois.nic.tm|is available for purchase
.vg|whois.adamsnames.tc|No Object Found
.tc|whois.adamsnames.tc|No Object Found
.ee|whois.tld.ee|no entries found
.academy|whois.donuts.co|Domain not found.
.agency|whois.donuts.co|Domain not found.
.airforce|whois.unitedtld.com|Domain not found
.archi|whois.ksregistry.net|not found
.arpa|whois.iana.org|0 objects
.associates|whois.donuts.co|Domain not found
.ax|whois.ax|No records matching
.bargains|whois.donuts.co|Domain not found.
.berlin|whois.nic.berlin|No match
.blue|whois.afilias.net|NOT FOUND
.boutique|whois.donuts.co|Domain not found.
.builders|whois.donuts.co|Domain not found
.build|whois.nic.build |No Data Found
.buzz|whois.nic.buzz|Not found:
.cab|whois.donuts.co|Domain not found.
.camp|whois.donuts.co|Domain not found.
.capetown|whois.nic.capetown|Available
.center|whois.donuts.co|Domain not found.
.cheap|whois.donuts.co|Domain not found.
.club|whois.nic.club|No Domain exists for the search string
.codes|whois.donuts.co|Domain not found.
.coffee|whois.donuts.co|Domain not found
.company|whois.donuts.co|Domain not found.
.computer|whois.donuts.co|Domain not found.
.cool|whois.donuts.co|Domain not found
.durban|whois.nic.durban|Available
.education|whois.donuts.co|Domain not found.
.email|whois.donuts.co|Domain not found.
.expert|whois.donuts.co|Domain not found
.exposed|whois.donuts.co|Domain not found.
.farm|whois.donuts.co|Domain not found.
.flights|whois.donuts.co|Domain not found
.florist|whois.donuts.co|Domain not found.
.futbol|whois.unitedtld.com|Domain not found
.gift|whois.uniregistry.net|is available for registration
.glass|whois.donuts.co|Domain not found.
.guitars|whois.uniregistry.net|is available for registration
.holiday|whois.donuts.co|Domain not found.
.house|whois.donuts.co|Domain not found.
.ink|whois.donuts.co|Domain not found
.institute|whois.donuts.co|Domain not found.
.international|whois.donuts.co|Domain not found.
.joburg|whois.nic.joburg|Available
.kim|whois.afilias.net|NOT FOUND
.limo|whois.donuts.co|Domain not found.
.link|whois.uniregistry.net|is available for registration
.luxury|whois.nic.luxury|No Data Found
.maison|whois.donuts.co|Domain not found
.management|whois.donuts.co|Domain not found.
.marketing|whois.donuts.co|Domain not found.
.menu|whois.nic.menu|No Data Found
.moda|whois.nic.moda|Domain not found
.ninja|whois.nic.ninja|Domain not found
.onl|whois.donuts.co|Domain not found
.pics|whois.uniregistry.net|is available for registration
.pink|whois.afilias.net|NOT FOUND
.repair|whois.donuts.co|Domain not found.
.sexy|whois.uniregistry.net|is available for registration
.shiksha|whois.nic.shiksha|NOT FOUND
.social|whois.unitedtld.com|Domain not found
.solar|whois.donuts.co|Domain not found.
.solutions|whois.donuts.co|Domain not found.
.supplies|whois.donuts.co|Domain not found.
.supply|whois.donuts.co|Domain not found.
.support|whois.donuts.co|Domain not found.
.systems|whois.donuts.co|Domain not found.
.tips|whois.donuts.co|Domain not found.
.training|whois.donuts.co|Domain not found.
.uno|whois.nic.uno|Not found
.viajes|whois.donuts.co|Domain not found.
.wiki|whois.donuts.co|Domain not found
.work|whois-dub.mm-registry.com|Not Registered
.zone|whois.donuts.co|Domain not found.
.co.zw|http://zispa.co.zw/cgi-bin/domain_lookup.pl?s=|HTTPREQUEST-is available for registration
.coop|whois.nic.coop|No domain records were found
.co.id|whois.pandi.or.id|DOMAIN NOT FOUND
.desa.id|whois.pandi.or.id|DOMAIN NOT FOUND
.web.id|whois.pandi.or.id|DOMAIN NOT FOUND
.ac.id|whois.pandi.or.id|DOMAIN NOT FOUND
.or.id|whois.pandi.or.id|DOMAIN NOT FOUND
.sch.id|whois.pandi.or.id|DOMAIN NOT FOUND
.my.id|whois.pandi.or.id|DOMAIN NOT FOUND
.biz.id|whois.pandi.or.id|DOMAIN NOT FOUND
.priv.no|whois.norid.no|No match
.idrett.no|whois.norid.no|No match
.attorney|whois.rightside.co|Domain not found
.world|whois.donuts.co|Domain not found
.top|whois.nic.top|The queried object does not exist
.co.tz|whois.tznic.or.tz|No entries found
.or.tz|whois.tznic.or.tz|No entries found
.go.tz|whois.tznic.or.tz|No entries found
.ne.tz|whois.tznic.or.tz|No entries found
.me.tz|whois.tznic.or.tz|No entries found
.tv.tz|whois.tznic.or.tz|No entries found
.ac.tz|whois.tznic.or.tz|No entries found
.sc.tz|whois.tznic.or.tz|No entries found
.irish|whois.afilias-srs.net|NOT FOUND
.lawyer|whois.rightside.co|Domain not found
.pub|whois.unitedtld.com|Domain not found
.pe|kero.yachay.pe|Not Registered
.com.pe|kero.yachay.pe|Not Registered
.accountant|whois.nic.accountant|No Domain exists
.accountants|whois.nic.accountants|Domain not found
.actor|whois.unitedtld.com|Domain not found
.adult|whois.afilias-srs.net|NOT FOUND
.apartments|whois.donuts.co|Domain not found
.ar.com|whois.centralnic.net|DOMAIN NOT FOUND
.army|whois.rightside.co|Domain not found
.auction|whois.unitedtld.com|Domain not found
.audio|whois.uniregistry.net|is available for registration
.band|whois.rightside.co|Domain not found
.bar|whois.nic.bar|DOMAIN NOT FOUND
.best|whois.nic.best|No Domain exists
.bid|whois.nic.bid|No Domain exists
.bingo|whois.donuts.co|Domain not found
.bio|whois.ksregistry.net|The queried object does not exist
.black|whois.afilias.net|NOT FOUND
.blackfriday|whois.uniregistry.net|is available for registration
.business|whois.donuts.co|Domain not found
.cafe|whois.donuts.co|Domain not found
.capital|whois.donuts.co|Domain not found
.cards|whois.donuts.co|Domain not found
.care|whois.donuts.co|Domain not found
.cash|whois.donuts.co|Domain not found
.casino|whois.donuts.co|Domain not found
.catering|whois.donuts.co|Domain not found
.ceo|whois.nic.ceo|No Domain exists
.chat|whois.donuts.co|Domain not found
.christmas|whois.uniregistry.net|is available for registration
.church|whois.donuts.co|Domain not found
.city|whois.donuts.co|Domain not found
.claims|whois.donuts.co|Domain not found
.cleaning|whois.donuts.co|Domain not found
.click|whois.uniregistry.net|is available for registration
.clinic|whois.donuts.co|Domain not found
.coach|whois.donuts.co|Domain not found
.college|whois.nic.college|DOMAIN NOT FOUND
.community|whois.donuts.co|Domain not found
.condos|whois.donuts.co|Domain not found
.consulting|whois.unitedtld.com|Domain not found
.coupons|whois.donuts.co|Domain not found
.courses|whois.aridnrs.net.au|No Data Found
.credit|whois.donuts.co|Domain not found
.creditcard|whois.donuts.co|Domain not found
.cricket|whois.nic.cricket|No Domain exists
.cruises|whois.donuts.co|Domain not found
.cymru|whois.nic.cymru|This domain name has not been registered
.dance|whois.unitedtld.com|Domain not found
.date|whois.nic.date|No Domain exists
.dating|whois.donuts.co|Domain not found
.deals|whois.donuts.co|Domain not found
.degree|whois.rightside.co|Domain not found
.delivery|whois.donuts.co|Domain not found
.democrat|whois.unitedtld.com|Domain not found
.dental|whois.donuts.co|Domain not found
.dentist|whois.rightside.co|Domain not found
.desi|whois.ksregistry.net|The queried object does not exist
.design|whois.nic.design|DOMAIN NOT FOUND
.diet|whois.uniregistry.net|is available for registration
.digital|whois.donuts.co|Domain not found
.direct|whois.donuts.co|Domain not found
.discount|whois.donuts.co|Domain not found
.dog|whois.donuts.co|Domain not found
.domains|whois.donuts.co|Domain not found
.download|whois.nic.download|No Domain exists
.earth|whois.nic.earth|No Domain exists
.energy|whois.donuts.co|Domain not found
.engineer|whois.rightside.co|Domain not found
.engineering|whois.donuts.co|Domain not found
.eus|whois.eus.coreregistry.net|no matching objects found
.events|whois.donuts.co|Domain not found
.exchange|whois.donuts.co|Domain not found
.express|whois.donuts.co|Domain not found
.fail|whois.donuts.co|Domain not found
.faith|whois.nic.faith|No Domain exists
.fans|whois.nic.fans|DOMAIN NOT FOUND
.film|whois.nic.film|No Data Found
.finance|whois.donuts.co|Domain not found
.financial|whois.donuts.co|Domain not found
.fish|whois.donuts.co|Domain not found
.fitness|whois.donuts.co|Domain not found
.flowers|whois.uniregistry.net|is available for registration
.football|whois.donuts.co|Domain not found
.forsale|whois.unitedtld.com|Domain not found
.foundation|whois.donuts.co|Domain not found
.fund|whois.donuts.co|Domain not found
.furniture|whois.donuts.co|Domain not found
.fyi|whois.donuts.co|Domain not found
.gal|whois.gal.coreregistry.net|no matching objects found
.gifts|whois.donuts.co|Domain not found
.gives|whois.rightside.co|Domain not found
.global|whois.nic.global|NOT FOUND
.gold|whois.donuts.co|Domain not found
.golf|whois.donuts.co|Domain not found
.gratis|whois.donuts.co|Domain not found
.green|whois.afilias.net|NOT FOUND
.gripe|whois.donuts.co|Domain not found
.guide|whois.donuts.co|Domain not found
.haus|whois.unitedtld.com|Domain not found
.healthcare|whois.donuts.co|Domain not found
.help|whois.uniregistry.net|is available for registration
.hiphop|whois.uniregistry.net|is available for registration
.hockey|whois.donuts.co|Domain not found
.host|whois.nic.host|DOMAIN NOT FOUND
.hosting|whois.uniregistry.net|is available for registration
.how|domain-registry-whois.l.google.com|Domain not found
.immo|whois.donuts.co|Domain not found
.immobilien|whois.unitedtld.com|Domain not found
.industries|whois.donuts.co|Domain not found
.insure|whois.donuts.co|Domain not found
.investments|whois.donuts.co|Domain not found
.jewelry|whois.donuts.co|Domain not found
.juegos|whois.uniregistry.net|is available for registration
.kaufen|whois.unitedtld.com|Domain not found
.lease|whois.donuts.co|Domain not found
.legal|whois.donuts.co|Domain not found
.lgbt|whois.afilias.net|NOT FOUND
.life|whois.donuts.co|Domain not found
.limited|whois.donuts.co|Domain not found
.live|whois.rightside.co|Domain not found
.loan|whois.nic.loan|No Domain exists
.loans|whois.donuts.co|Domain not found
.lol|whois.uniregistry.net|is available for registration
.london|whois-lon.mm-registry.com
.love|whois.nic.love|DOMAIN NOT FOUND
.ltda|whois.afilias-srs.net|NOT FOUND
.market|whois.rightside.co|Domain not found
.mba|whois.donuts.co|Domain not found
.media|whois.donuts.co|Domain not found
.melbourne|whois.aridnrs.net.au|No Data Found
.memorial|whois.donuts.co|Domain not found
.men|whois.nic.men|No Data Found
.moe|whois.nic.moe|No Domain exists
.money|whois.donuts.co|Domain not found
.mortgage|whois.rightside.co|Domain not found
.movie|whois.donuts.co|Domain not found
.navy|whois.rightside.co|Domain not found
.network|whois.donuts.co|Domain not found
.news|whois.rightside.co|Domain not found
.ngo|whois.publicinterestregistry.net
.one|whois.nic.one|No Data Found
.ong|whois.publicinterestregistry.net
.online|whois.centralnic.com|DOMAIN NOT FOUND
.osaka|whois.nic.osaka|No Domain exists
.paris|whois-paris.nic.fr|The queried object does not exist
.partners|whois.donuts.co|Domain not found
.parts|whois.donuts.co|Domain not found
.party|whois.nic.party|No Domain exists
.photo|whois.uniregistry.net|is available for registration
.pictures|whois.donuts.co|Domain not found
.pizza|whois.donuts.co|Domain not found
.place|whois.donuts.co|Domain not found
.plumbing|whois.donuts.co|Domain not found
.plus|whois.donuts.co|Domain not found
.poker|whois.afilias.net|NOT FOUND
.porn|whois.afilias-srs.net|NOT FOUND
.press|whois.nic.press|DOMAIN NOT FOUND
.productions|whois.donuts.co|Domain not found
.properties|whois.donuts.co|Domain not found
.property|whois.uniregistry.net|is available for registration
.quebec|whois.nic.quebec|no matching objects found
.racing|whois.nic.racing|No Domain exists
.red|whois.afilias.net|NOT FOUND
.rehab|whois.rightside.co|Domain not found
.reise|whois.nic.reise|Domain not found
.reisen|whois.donuts.co|Domain not found
.rent|whois.nic.rent|DOMAIN NOT FOUND
.rentals|whois.donuts.co|Domain not found
.report|whois.donuts.co|Domain not found
.republican|whois.rightside.co|Domain not found
.rest|whois.nic.rest|DOMAIN NOT FOUND
.restaurant|whois.donuts.co|Domain not found
.review|whois.nic.review|No Domain exists
.reviews|whois.unitedtld.com|Domain not found
.rich|whois.afilias-srs.net|NOT FOUND
.rip|whois.rightside.co|Domain not found
.rocks|whois.unitedtld.com|Domain not found
.run|whois.donuts.co|Domain not found
.sale|whois.rightside.co|Domain not found
.sarl|whois.donuts.co|Domain not found
.school|whois.donuts.co|Domain not found
.schule|whois.donuts.co|Domain not found
.science|whois.nic.science|No Domain exists
.services|whois.donuts.co|Domain not found
.sex|whois.afilias-srs.net|NOT FOUND
.show|whois.donuts.co|Domain not found
.site|whois.centralnic.com|DOMAIN NOT FOUND
.ski|whois.ksregistry.net|The queried object does not exist
.soccer|whois.donuts.co|Domain not found
.software|whois.rightside.co|Domain not found
.soy|domain-registry-whois.l.google.com|Domain not found
.space|whois.nic.space|DOMAIN NOT FOUND
.srl|whois.afilias-srs.net|NOT FOUND
.studio|whois.rightside.co|Domain not found
.study|whois.nic.study|No Data Found
.style|whois.donuts.co|Domain not found
.sucks|whois.nic.sucks|No Data Found
.surgery|whois.donuts.co|Domain not found
.sydney|whois.nic.sydney|No Data Found
.tattoo|whois.uniregistry.net|is available for registration
.tax|whois.donuts.co|Domain not found
.taxi|whois.donuts.co|Domain not found
.team|whois.donuts.co|Domain not found
.tech|whois.nic.tech|DOMAIN NOT FOUND
.tennis|whois.donuts.co|Domain not found
.theater|whois.donuts.co|Domain not found
.tienda|whois.donuts.co|Domain not found
.tires|whois.donuts.co|Domain not found
.tools|whois.donuts.co|Domain not found
.tours|whois.donuts.co|Domain not found
.town|whois.donuts.co|Domain not found
.toys|whois.donuts.co|Domain not found
.trade|whois.nic.trade|No Domain exists
.university|whois.donuts.co|Domain not found
.vacations|whois.donuts.co|Domain not found
.vegas|whois.afilias-srs.net|NOT FOUND
.vet|whois.rightside.co|Domain not found
.video|whois.rightside.co|Domain not found
.villas|whois.donuts.co|Domain not found
.vision|whois.donuts.co|Domain not found
.vote|whois.afilias.net|NOT FOUND
.voting|whois.voting.tld-box.at
.voto|whois.afilias.net|NOT FOUND
.wales|whois.nic.wales|This domain name has not been registered
.watch|whois.donuts.co|Domain not found
.webcam|whois.nic.webcam|No Domain exists
.website|whois.nic.website|DOMAIN NOT FOUND
.win|whois.nic.win|No Domain exists
.works|whois.donuts.co|Domain not found
.wtf|whois.donuts.co|Domain not found
.xyz|whois.nic.xyz|DOMAIN NOT FOUND
.ru.com|whois.verisign-grs.com|No match for
.swiss|whois.nic.swiss|The queried object does not exist: no matching objects found
.mk|whois.marnet.mk|No entries found
.com.mk|whois.marnet.mk|No entries found
.org.mk|whois.marnet.mk|No entries found
.net.mk|whois.marnet.mk|No entries found
.inf.mk|whois.marnet.mk|No entries found
.edu.mk|whois.marnet.mk|No entries found
.cloud|whois.nic.cloud|No Data Found

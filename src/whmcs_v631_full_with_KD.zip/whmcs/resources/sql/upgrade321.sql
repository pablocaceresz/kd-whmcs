INSERT INTO `tblconfiguration` (`setting` ,`value` ) VALUES ('ProductMonthlyPricingBreakdown', '');

UPDATE `tblconfiguration` SET value='cart' where setting = 'OrderFormTemplate' and value='singlepage';
